#include <iostream>
#include <windows.h>
using namespace std;

string ExePath(char buffer[]) {
    string::size_type pos = string(buffer).find_last_of("\\/");
    return string(buffer).substr(0, pos+1);
}

void startup(LPCTSTR lpApplicationName, LPCTSTR lpCurrentDirectory){
    STARTUPINFO si;
    PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));
    if (!CreateProcessA(lpApplicationName, NULL, NULL, NULL, 0, 0, NULL, lpCurrentDirectory, &si, &pi)){
        cout << "Create Process failed: " << GetLastError() << endl;
    }
}

int main(int args, char *argv[]){
    char pszOldWindowTitle[MAX_PATH];
    GetConsoleTitle(pszOldWindowTitle, MAX_PATH);
    HWND myHWND = FindWindowA(NULL, pszOldWindowTitle);
    ShowWindow(myHWND, SW_HIDE);
    if (argv[1] == NULL) exit(1);
    string myExe = ExePath(argv[0])+argv[1];
    startup(myExe.c_str(), ExePath(argv[0]).c_str());
    return 0;
}
